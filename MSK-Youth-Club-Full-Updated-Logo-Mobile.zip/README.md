# MSK Youth Club - Full Updated Version

## Included
- Admin and Member login
- Add member with monthly contribution amount
- Month-wise paid/pending list
- Member pending amount and pending months
- Monthly collection
- Varavu / Income add, edit, delete
- Selavu / Expense add, edit, delete
- Club total income, expense and balance
- Member can view club Varavu/Selavu and totals
- Member payment history
- Excel and PDF reports
- Mobile responsive UI
- MongoDB + Express + React + JWT

## Setup

1. Install Node.js and MongoDB.
2. Copy `server/.env.example` to `server/.env`.
3. Set your values in `.env`.
4. From project root:

```bash
npm install
npm run install:all
npm run dev
```

Frontend: http://localhost:5173
Backend: http://localhost:4000

Default admin from the example `.env`:
Email: admin@mskyouthclub.local
Password: 123456

Change the password before using the application seriously.

## Finance logic

Member monthly payment is stored separately as a Payment.
Admin-entered additional Varavu is stored in Income.
Admin-entered Selavu is stored in Expense.

Club total Varavu =
member payment collection + additional Varavu.

Club balance =
total Varavu - total Selavu.

Member pending amount =
expected monthly contribution from the member's join month through the current month minus the member's recorded payments.


### Latest UI update
- Added the provided MSK Youth Club logo to the login page, top navigation, and browser favicon.
- Added a more distinctive gold/navy visual style while keeping the mobile-responsive layout.
