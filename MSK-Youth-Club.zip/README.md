# MSK Youth Club – React + Node + MongoDB

## Features
- Separate Admin and Member login
- Admin can add, activate/deactivate and delete members
- Each member gets a login account
- Member dashboard/overview
- Monthly payment recording
- Payment history
- Varavu (income) and Selavu (expense)
- Club balance = total payments - total expenses
- Excel downloads using XLSX
- PDF downloads using jsPDF + AutoTable
- JWT authentication
- MongoDB storage

## Requirements
- Node.js
- MongoDB running locally
- VS Code

## Setup

### 1. Install
Open a terminal in the project folder:

```bash
npm install
npm run install:all
```

### 2. Backend .env
Copy:

`server/.env.example` → `server/.env`

Then set your own values. Example:

```env
PORT=4000
MONGO_URI=mongodb://127.0.0.1:27017/msk-youth-club
JWT_SECRET=your_long_random_secret
ADMIN_EMAIL=admin@mskyouthclub.local
ADMIN_PASSWORD=your_admin_password
```

Do not upload `.env` to GitHub.

### 3. Run
From the project root:

```bash
npm run dev
```

Frontend:
`http://localhost:5173`

Backend:
`http://localhost:4000`

### 4. First login
Use the ADMIN_EMAIL and ADMIN_PASSWORD from your `.env`.

The admin account is created automatically the first time the server connects to MongoDB.

### 5. Add a member
Admin → Members → Add Member.

The member receives:
- Name
- Email
- Phone
- Password

The member can then log in from the same login page.

### 6. Record monthly payment
Admin → Payments → select member → month → year → amount → Mark Paid.

The member can see the payment in their dashboard.

### 7. Download
Admin can download:
- Members Excel/PDF
- Payments Excel/PDF
- Expenses Excel/PDF

Member can download:
- Their own payment Excel
- Their own payment PDF

## Important
The `monthlyAmount` field is stored in the member-creation UI for reference in this starter version. The actual payment amount is entered when the admin records each month's payment.
